# FlightWatch – plan sesji z Claude Code (wersja po przeglądzie 10x)

Cel: system zbiera ceny WAW→DPS dla 2+1 automatycznie od **11.10.2026**.
Termin decyzji zakupowej: 15.11.2026 (TERMIN 8.11). Próg zakupu: 11 000 zł za 3 osoby z bagażem i miejscami.
Pełny plan zadań: `.10x/decisions/engineering-manager/flightwatch-mvp.md`.

## Przygotowanie (Ty, ok. 45 min, do 4.10)
- [ ] VPS Ubuntu 24.04, dostęp SSH kluczem
- [ ] Konto Ignav → klucz API
- [ ] Konto SerpApi → klucz (250 darmowych wyszukań/mies.)
- [ ] Bot Telegrama przez @BotFather → token i chat_id
- [ ] healthchecks.io → 3 checki (scan-full, scan-confirm, bot)
- [ ] (opcjonalnie) Backblaze B2 na kopie zapasowe
- [ ] Prywatne repo: `CLAUDE.md`, `config.yaml`, `PLAN_SESJI.md`, katalog `.10x/`
- [ ] Zaakceptuj spec (`.10x/specs/…-design.md`, §9) i popraw wartości SZACUNEK w `config.yaml`

## Sesje
0. **Spike (4.10, ok. 1 h):** prawdziwe zapytania Ignav i SerpApi dla 2+1, zapis fixtures, tabela możliwości. Bramka: czy Ignav daje ceny grupy z dzieckiem i warunki taryfy.
1. **Szkielet (5.10):** repo, uv, CI, config + walidacja, schemat SQLite + migracje, modele i kontrakty, `Provider`, lotniska, logi z redakcją.
2. **Dostawcy (6–7.10):** Ignav, SerpApi insights, fast-flights, łańcuch awaryjny, budżet, cache, kursy NBP.
3. **Silnik (8.10):** normalizacja, filtry kierunkowe (DST!), kwota do zapłaty z `fare_rules.yaml`, koszt K, ranking 3 opcji.
4. **Decyzje i alerty (9.10):** KUP / BLISKO / TERMIN / MISTAKE_FARE, deduplikacja, bot `/status` `/top3` `/kupione` `/budzet`.
5. **Serwer (10.10):** hardening, systemd timers, heartbeat, backup + test odtworzenia, pierwszy prawdziwy skan.
6. **Rozszerzenia (od 12.10, osobny brainstorming):** huby i osobne bilety, dolot tanią linią (WMI/VIE/PRG/BUD), warianty elastyczności, open-jaw, monitor po zakupie, Streamlit.

## Prompt startowy (sesja 0)
> Przeczytaj `CLAUDE.md`, `config.yaml` i `.10x/handoff.md`. Wykonaj sesję 0 (spike): napisz jednorazowy skrypt `scripts/spike_ignav.py` i `scripts/spike_serpapi.py`, które wykonają po kilka zapytań WAW→DPS dla 2 dorosłych i dziecka 4 lata (w obie strony 22.12.2026→20.03.2027, w jedną stronę, wiele lotnisk wylotu naraz, jeśli API pozwala). Klucze z `.env`. Zapisz surowe odpowiedzi do `tests/fixtures/`. Uzupełnij w `.10x/decisions/sde/flightwatch-mvp.md` tabelę: cena grupy z dzieckiem, cena za osobę, warunki zmiany/zwrotu, marka taryfy, bagaż, link do rezerwacji, waluta, wiele lotnisk w zapytaniu, koszt zapytania. Zaproponuj zmiany w ADR-002/004, jeśli wynik tego wymaga. Nie twórz kodu produkcyjnego.

## Prompt startowy (sesja 1)
W `.10x/decisions/senior-engineer/flightwatch-mvp.md`.
