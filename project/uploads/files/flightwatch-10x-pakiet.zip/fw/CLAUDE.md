# FlightWatch – zasady projektu dla Claude Code

Osobisty monitor cen lotów. Pierwsza obserwacja: rodzina 2+1 (dziecko 4 lata), WAW→DPS,
wylot 20–31.12.2026, powrót 15–31.03.2027, przylot na Bali 05:00–12:59.
Cała konfiguracja jest w `config.yaml` – nigdy nie wpisuj wartości na sztywno w kodzie.

**Przed każdą sesją przeczytaj `.10x/status.md` i `.10x/handoff.md`.** Decyzje architektoniczne są w `.10x/adrs/`
(zmiana = nowy ADR), kontrakty w `.10x/decisions/architect/flightwatch-mvp.md`, schemat w `.10x/decisions/dba/`.
Po sesji zaktualizuj `.10x/decisions/sde/flightwatch-mvp.md`, `.10x/status.md` i `.10x/handoff.md`.

## Stack
Python 3.12, uv, SQLite (WAL), httpx, pydantic v2, Typer, pytest (+ time-machine, respx, hypothesis),
ruff, mypy, python-telegram-bot, Streamlit (później).
Uruchamiane na serwerze Linux przez systemd timers (skany) i usługę systemd (bot). Klucze tylko w `.env` (nigdy w repo).

## Zasady, których kod musi przestrzegać
1. **Ceny zawsze dla całej grupy pasażerów.** Każde zapytanie wysyła liczbę dorosłych i dzieci.
   Nigdy nie mnoż ceny jednej osoby. Zapisuj cenę łączną i cenę za dorosłego.
2. **Dwie różne liczby:**
   - *kwota do zapłaty* = bilety + bagaż + miejsca obok siebie → porównywana z progiem 11 000 zł;
   - *koszt efektywny K* = kwota do zapłaty + dojazd + nocleg + wartość czasu + kary → tylko ranking.
3. **Żadnego alertu KUP bez świeżej ceny live** (nie starszej niż 60 min) i linku do rezerwacji.
4. **Filtry zależne od typu trasy** (wspólny bilet / osobne bilety / dolot tanią linią) i osobne
   dla każdego kierunku. Szczegóły w `config.yaml → filters`.
5. **Elastyczny powrót to wartość, nie wymóg.** Oferta bez możliwości zmiany daty powrotu dostaje
   karę `flex_value_pln` w rankingu. Zapisuj osobno: opłatę za zmianę, dopłatę różnicy taryfy, zwrot.
6. **Wymienne źródła danych.** Każdy dostawca implementuje interfejs `Provider`; błąd lub koniec
   limitu → następny w kolejności. Każde zapytanie logowane w tabeli `queries` z kosztem.
7. **Budżet zapytań to twarde ograniczenie.** Planer sprawdza budżet przed każdym wywołaniem.
8. **Waluty:** zapisuj cenę oryginalną i przeliczoną na PLN po kursie z dnia obserwacji (`fx_rates`).
9. **Czas lokalny:** godziny przylotu liczone w strefie czasowej lotniska (IANA).
10. **Statystyki tylko z danych live.** Ocena Google (low/typical/high) to kontekst, nie wyzwalacz zakupu.
11. **Nie implementuj:** hidden city, modelu ML, biletów nagrodowych, automatycznej rezerwacji.
12. **Pieniądze jako `int` w groszach** (`*_minor`), kursy jako `Decimal`. Nigdy `float` dla kwot.
13. **KUP tylko dla oferty kwalifikującej się:** filtry twarde OK, cena live ≤ 60 min, `price_basis="group_quoted"`,
    znany koszt bagażu i miejsc (`data/fare_rules.yaml`), kurs NBP ≤ 3 dni, link `https://`.
14. **Nieznane warunki zmiany = brak elastyczności** (kara `flex_value_pln`) i etykieta „warunki nieznane”.
15. **Sekrety nigdy w logach:** filtr redagujący w `flightwatch/logging.py`, test na to.
16. **Bot obsługuje tylko `TELEGRAM_CHAT_ID`.** Inne czaty ignorowane.
17. **`engine/` to czyste funkcje** – bez importów z `db/`, `providers/`, `alerts/`. SQL tylko w `db/repo.py`.
18. **Brak strefy czasowej lotniska = błąd** z kodem IATA, nigdy cichy UTC.

## Model danych (SQLite)
Pełny opis kolumn i indeksów: `.10x/decisions/dba/flightwatch-mvp.md`.
`watches`, `origins`, `airports` (IATA, strefa czasowa), `runs`, `queries`, `itineraries`
(klucz = loty + daty + taryfa), `segments`, `offers` (snapshot ceny: łączna, za dorosłego,
waluta, PLN, źródło, observed_at, link, warunki zmiany), `fare_rules` (linia + taryfa →
opłata za zmianę, zwrot, łączenie taryf, bagaż, miejsca), `evaluations` (kwota, K, powody, wersja configu),
`google_insights`, `fx_rates`, `stats_daily`, `alerts`, `purchases`.

## Styl pracy
- Każda sesja kończy się działającym kodem i zielonymi testami (`pytest`, `ruff check`, `mypy` dla silnika).
- Testy dostawców na zapisanych odpowiedziach (fixtures), bez prawdziwych wywołań API w CI.
- Małe moduły: `providers/`, `planner/`, `engine/` (filtry, K, decyzje), `alerts/`, `db/` – układ w `.10x/decisions/architect/`.
- Czas: UTC w środku, `zoneinfo` tylko przy filtrach i wyświetlaniu; zegar wstrzykiwany (`Clock`).
- Komentarze i komunikaty dla użytkownika po polsku, kod i nazwy po angielsku.
