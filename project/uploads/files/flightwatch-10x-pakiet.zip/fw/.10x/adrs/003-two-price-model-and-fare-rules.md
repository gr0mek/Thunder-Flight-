# ADR-003: Dwie liczby (kwota do zapłaty / koszt K) i ręczne reguły taryf

**Status:** Proponowany
**Date:** 2026-10-03
**Feature:** flightwatch-mvp
**Author:** 10x-Team (Architect + Staff Engineer)

## Context
Próg 11 000 zł dotyczy realnego wydatku (bilety + bagaż + miejsca). Ranking ma uwzględniać czas, dojazd i elastyczność. API lotów zwykle nie podaje bagażu, opłat za miejsca ani pełnych warunków zmiany.

## Decision
- `engine.pricing.payable()` → kwota do zapłaty; `engine.cost.effective()` → K. Funkcje czyste, wynik zapisany w `evaluations` z `config_hash`, więc zmiana `value_of_hour` przelicza ranking bez nowych zapytań.
- `data/fare_rules.yaml` (w repo, edytowany ręcznie): `carrier + fare_brand` → bagaż w cenie, opłata za bagaż, opłata za miejsce/os., dzieci siedzą z rodzicem bez dopłaty, zmiana daty (opłata, różnica taryfy), zwrot, `verified_at`.
- Brak reguły → `ancillaries_known=false` → oferta w rankingu, ale bez KUP. Raport tygodniowy listuje linie bez reguł.
- Nieznane warunki zmiany → traktowane jak brak elastyczności (kara `flex_value_pln`) z etykietą „warunki nieznane”.
- Kwoty jako liczby całkowite w groszach; kurs jako `Decimal`.

## Alternatives Considered
| Alternatywa | Zalety | Wady | Dlaczego nie |
|---|---|---|---|
| Jedna liczba K także do decyzji | prostsze | „kup” zależny od szacunków wartości czasu | sprzeczne z CLAUDE.md |
| Scraping stron linii po bagaż | automatycznie | kruche, czasochłonne | dla ~6 linii ręczny plik wystarczy |
| Stała dopłata za bagaż na osobę | prosto | błędy rzędu setek zł przy progu | zbyt niedokładne przy progu |

## Consequences
### Positive
- Decyzja zakupowa nie zależy od subiektywnych parametrów.
### Negative
- Ręczna praca: uzupełnienie reguł dla linii, które pojawią się w danych (ok. 30 min po pierwszym skanie).
### Risks
- Nieaktualne reguły → pole `verified_at`, ostrzeżenie w alercie KUP gdy > 30 dni.

## Dependencies
Wymaga listy linii z pierwszego skanu (sesja 2).
