# ADR-002: Interfejs Provider z deklaracją możliwości i bramka budżetu

**Status:** Proponowany
**Date:** 2026-10-03
**Feature:** flightwatch-mvp
**Author:** 10x-Team (Architect + Staff Engineer)

## Context
Dostawcy różnią się możliwościami (ceny z dziećmi, warunki taryfy, wiele lotnisk w zapytaniu, link), stabilnością (fast-flights nieoficjalny) i kosztem. Budżet zapytań jest twardym ograniczeniem (CLAUDE.md, zasada 7).

## Decision
- `Provider` (ABC): `name`, `capabilities: ProviderCapabilities`, `cost_per_query: int`, `search(query) -> list[Offer]`.
- `ProviderCapabilities`: `group_pricing`, `child_ages`, `fare_conditions`, `multi_origin`, `booking_link`, `is_live`.
- Oferta od dostawcy bez `group_pricing` dostaje `price_basis="estimated"` i **nie może wywołać KUP**.
- `ProviderChain` próbuje dostawców w kolejności z configu; wyjątki: `TransientProviderError` (ponów), `PermanentProviderError` (następny), `BudgetExceeded` (pomiń).
- `BudgetLedger.reserve()` liczy zużycie z tabeli `queries` w bieżącym miesiącu i odmawia przed wywołaniem.

## Alternatives Considered
| Alternatywa | Zalety | Wady | Dlaczego nie |
|---|---|---|---|
| Jeden dostawca na sztywno (Ignav) | mniej kodu | brak zapasu przy awarii lub końcu limitu | sprzeczne z CLAUDE.md |
| Liczenie budżetu w pamięci | szybkie | gubi się między procesami | skany to osobne procesy |
| Agregator (Travelpayouts) jako główny | darmowy | słabe pokrycie WAW–DPS, dane z cache | nie daje cen live |

## Consequences
### Positive
- Planer wybiera strategię po `capabilities` (np. jedno zapytanie na wiele lotnisk, jeśli dostawca to wspiera).
### Negative
- Każdy nowy dostawca wymaga fixtures i deklaracji możliwości.
### Risks
- Ignav może nie wspierać wieku dziecka → wtedy KUP tylko po potwierdzeniu innym źródłem. Weryfikacja w sesji 0.

## Dependencies
Zależy od wyniku spike'a Ignav (sesja 0).
