# ADR-004: Skan warstwowy w granicach budżetu Ignav

**Status:** Proponowany
**Date:** 2026-10-03
**Feature:** flightwatch-mvp
**Author:** 10x-Team (Architect + Staff Engineer)

## Context
Pierwotny harmonogram (2 pełne skany × 8 lotnisk) to ≈ 23 000 zapytań/mies. przy budżecie 8 000.

## Decision
| Przebieg | Godzina | Zakres | Zapytań/dzień |
|---|---|---|---|
| `scan --mode full` | 07:30 | WAW, KRK, GDN, BER × 12 dat × 4 próbki powrotu | 192 |
| `scan --mode confirm` | 19:30 | top 20 kombinacji z 24 h (wg kwoty i K) | 20 |
| potwierdzenia spadków / KUP | na żądanie | rezerwa 15% budżetu (1 200/mies.) | do ~40 |
| `insights` (SerpApi) | 08:00 | 1–2 najlepsze kombinacje | 1–2 |

Razem: 212/dzień ≈ 6 400/mies. stałego zużycia + rezerwa do 1 200 = maks. ≈ 7 600/mies. Ignav (95% budżetu). SerpApi ≈ 60/mies.
Jeśli spike pokaże, że Ignav obsługuje wiele lotnisk w jednym zapytaniu, pełny skan spada do 48 zapytań i wieczorem można robić drugi pełny skan.

## Alternatives Considered
| Alternatywa | Zalety | Wady | Dlaczego nie |
|---|---|---|---|
| 2 pełne skany, mniej lotnisk (tylko WAW) | prosto | traci KRK/GDN/BER | gubi tańsze trasy |
| Zwiększyć budżet Ignav | pełne dane | ok. 3× koszt | niepotrzebne przy warstwach |
| Radar z Travelpayouts + potwierdzanie live | tani radar | słabe pokrycie WAW–DPS | wyłączony w configu |

## Consequences
### Positive
- Mieści się w budżecie z rezerwą na reakcję na spadki.
### Negative
- Wieczorem świeże są tylko najlepsze kombinacje.
### Risks
- Planer musi deterministycznie wybierać top 20 (test).

## Dependencies
`config.yaml → planner`, wynik sesji 0.
