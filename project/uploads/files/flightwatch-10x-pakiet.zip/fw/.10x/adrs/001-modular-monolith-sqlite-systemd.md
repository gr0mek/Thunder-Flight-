# ADR-001: Modularny monolit w Pythonie, SQLite (WAL) i systemd timers

**Status:** Proponowany
**Date:** 2026-10-03
**Feature:** flightwatch-mvp
**Author:** 10x-Team (Architect + Staff Engineer)

## Context
Jeden użytkownik, jedna obserwacja, kilkaset zapytań dziennie, MVP za 8 dni, implementacja głównie przez Claude Code. Potrzebne: zaplanowane skany, stały bot Telegrama, trwała historia cen.

## Decision
- Jeden pakiet `flightwatch` z modułami `providers/ planner/ engine/ alerts/ db/` i CLI (Typer).
- SQLite w trybie WAL, `busy_timeout=5000`, `foreign_keys=ON`. Migracje jako ponumerowane pliki SQL + tabela `schema_version` (bez Alembica).
- Skany jako `oneshot` uruchamiane przez systemd timers, z `flock` na pliku blokady. Bot jako osobna usługa `Restart=always`.

## Alternatives Considered
| Alternatywa | Zalety | Wady | Dlaczego nie |
|---|---|---|---|
| GitHub Actions cron + SQLite w repo | zero serwera | commit bazy przy każdym skanie, brak stałego bota, IP chmury blokowane przez fast-flights | bot wymaga stałego procesu |
| Postgres/Supabase + kolejka zadań | skalowalność, panel w sieci | więcej infrastruktury i kosztów, wolniejszy start | YAGNI dla 1 użytkownika |
| cron zamiast systemd | prostszy zapis | brak logów w journald, brak `Persistent=` po restarcie | systemd daje nadrobienie pominiętego skanu |

## Consequences
### Positive
- Jeden plik bazy = prosta kopia zapasowa i debugowanie.
- Moduły testowalne osobno, czyste funkcje w `engine/`.
### Negative
- Jeden zapisujący naraz; wymaga dyscypliny (krótkie transakcje).
### Risks
- `database is locked` przy kolizji bota i skanu → WAL + busy_timeout + krótkie transakcje.

## Dependencies
Ogranicza: panel Streamlit (sesja 6) czyta tę samą bazę tylko do odczytu.
