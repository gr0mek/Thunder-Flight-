# ADR-005: Bot Telegrama w trybie long polling z listą dozwolonych czatów

**Status:** Proponowany
**Date:** 2026-10-03
**Feature:** flightwatch-mvp
**Author:** 10x-Team (Architect + Staff Engineer)

## Context
Bot musi odbierać komendy (`/status`, `/top3`, `/kupione`, `/budzet`) i jest dostępny publicznie dla każdego, kto zna jego nazwę.

## Decision
- `python-telegram-bot` w trybie long polling jako usługa systemd (bez otwartych portów, bez HTTPS).
- Wysyłka alertów ze skanów przez proste wywołanie HTTP Bot API (bez stałego procesu).
- Każda komenda sprawdza `chat_id == TELEGRAM_CHAT_ID`; inne czaty są ignorowane i logowane.
- `/kupione` wymaga potwierdzenia przyciskiem (kasuje obserwację i włącza tryb po zakupie).

## Alternatives Considered
| Alternatywa | Zalety | Wady | Dlaczego nie |
|---|---|---|---|
| Webhook | brak stałego połączenia | domena, TLS, otwarty port | większa powierzchnia ataku |
| Tylko powiadomienia, bez komend | bez procesu | brak `/status`, `/kupione` | wymagane w planie |

## Consequences
### Positive
- Brak ruchu przychodzącego na serwer.
### Negative
- Jeden stały proces do monitorowania.
### Risks
- Restart bota w trakcie potwierdzenia → potwierdzenie ważne 10 min, stan w bazie.

## Dependencies
Token i chat_id z przygotowania.
