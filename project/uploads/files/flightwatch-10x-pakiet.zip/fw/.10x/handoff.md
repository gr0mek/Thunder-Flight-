# Handoff → SDE (sesja 0, potem sesja 1)

**Od:** Engineering Manager + Senior Engineer · **Data:** 2026-10-03

## Kontekst
Projekt zatwierdzany w całości przed kodem. Przeczytaj w tej kolejności:
1. `specs/2026-10-03-flightwatch-mvp-design.md`
2. `reviews/2026-10-03-design-review.md` (15 ustaleń – już uwzględnione w configu)
3. ADR 001–005
4. `decisions/architect/`, `staff-engineer/`, `dba/`, `qa/`, `senior-engineer/`

## Najpierw sesja 0 (spike, bez kodu produkcyjnego)
Skrypt jednorazowy w `scripts/spike_ignav.py` (poza pakietem): zapytania WAW→DPS 2+1 RT 22.12→20.03, OW, multi-origin. Zapisz surowe JSON do `tests/fixtures/ignav/` i `tests/fixtures/serpapi/`. Wynik: tabela możliwości w `decisions/sde/flightwatch-mvp.md` i aktualizacja ADR-002 (lub nowy ADR, jeśli Ignav odpada).

## Potem sesja 1
Zadania T1.1–T1.4, prompt w `decisions/senior-engineer/flightwatch-mvp.md`.

## Nie zmieniaj bez nowego ADR
Kontrakty `Offer`/`SearchQuery`/`Evaluation`, model dwóch liczb, strategia skanu warstwowego.
