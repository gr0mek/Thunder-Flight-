# Status – FlightWatch

**Feature:** flightwatch-mvp
**Faza:** Planowanie zakończone (fazy 0–3) – **czeka na akceptację specu**
**Aktualizacja:** 2026-10-03

| Faza | Stan | Artefakty |
|---|---|---|
| 0 Brainstorming | ✅ (poprzednie sesje + przegląd) | `specs/2026-10-03-flightwatch-mvp-design.md`, `reviews/2026-10-03-design-review.md` |
| 1 Strategia | ✅ | `decisions/cto/`, `decisions/product-manager/` |
| 2 Projekt | ✅ | ADR 001–005, `decisions/architect/`, `decisions/staff-engineer/`, `decisions/dba/`, `decisions/security/` |
| 3 Planowanie | ✅ | `decisions/engineering-manager/`, `decisions/senior-engineer/`, `decisions/qa/`, `decisions/devops/`, `decisions/sre/` |
| 4 Implementacja | ⏳ czeka na akceptację + S0 | – |
| 5 Weryfikacja | – | – |
| 6 Dostarczenie | – | – |

## Zadania
- [ ] Akceptacja specu (3 pytania otwarte w §9)
- [ ] S0 spike Ignav/SerpApi (4.10)
- [ ] S1 T1.1–T1.4 (5.10)
- [ ] S2 T2.1–T2.5 (6–7.10)
- [ ] S3 T3.1–T3.3 (8.10)
- [ ] S4 T4.1–T4.3 (9.10)
- [ ] S5 T5.1–T5.4 (10.10)
- [ ] Start zbierania (11.10)

## Blokery
- Brak kluczy API (przygotowanie po Twojej stronie).
- Możliwości Ignav niezweryfikowane (S0).
