# DBA – flightwatch-mvp

Projekt schematu przed implementacją (migracja `001_init.sql` w sesji 1). PRAGMA przy każdym połączeniu: `journal_mode=WAL`, `busy_timeout=5000`, `foreign_keys=ON`, `synchronous=NORMAL`.

## Zasady
- Kwoty: `INTEGER` w groszach (`*_minor`) + `currency TEXT(3)`. Kursy: `TEXT` z `Decimal`.
- Czas: `TEXT` ISO 8601 w UTC (`..._utc`); lokalny czas segmentu zapisany obok dla czytelności.
- Oferty to **snapshoty** (insert-only). Itinerarium to stały obiekt identyfikowany kluczem.
- Wyliczenia (kwota, K) w osobnej tabeli `evaluations` z `config_hash` → zmiana configu nie niszczy historii.

## Tabele
| Tabela | Kluczowe kolumny | Uwagi |
|---|---|---|
| `schema_version` | version, applied_at | migracje |
| `watches` | id PK, name, active, config_hash | synchronizowana z configu przy starcie |
| `airports` | iata PK, name, city, country, tz | z `data/airports.yaml` |
| `origins` | watch_id, iata, mode, cost_pln_minor, hours | snapshot z configu |
| `runs` | id, kind, started_at_utc, finished_at_utc, status, n_queries, n_offers, config_hash, error | **nowa** – dla SRE |
| `queries` | id, run_id FK, provider, kind, request_hash, params_json, status, http_status, cost_units, latency_ms, error, raw_path, created_at_utc | budżet i cache |
| `itineraries` | id, itinerary_key UNIQUE, watch_id, route_type, trip_type, origin, destination, out_date, ret_date, hours_out, hours_ret, stops_out, stops_ret, carriers, first_seen_utc, last_seen_utc | |
| `segments` | id, itinerary_id FK, direction, seq, carrier, flight_no, dep_iata, arr_iata, dep_utc, arr_utc, dep_local, arr_local, ticket_group | |
| `offers` | id, itinerary_id FK, query_id FK, provider, observed_at_utc, total_minor, currency, total_pln_minor, per_adult_pln_minor, fx_rate_date, price_basis, fare_brand_out, fare_brand_ret, booking_url, change_allowed, change_fee_minor, fare_diff_applies, refund_allowed, conditions_source | |
| `evaluations` | offer_id FK, config_hash, passes, reasons_json, payable_pln_minor, ancillaries_known, effective_cost_pln_minor, components_json, buy_eligible; PK(offer_id, config_hash) | **nowa** |
| `fare_rules` | carrier, fare_brand, bags_included, bag_fee_minor, seat_fee_minor, kids_seated_free, change_allowed, change_fee_minor, refund_allowed, mix_allowed, currency, verified_at; PK(carrier, fare_brand) | ładowana z `data/fare_rules.yaml` |
| `fx_rates` | date, currency, rate_to_pln, source; PK(date, currency) | NBP tabela A |
| `google_insights` | id, watch_id, observed_at_utc, out_date, ret_date, level, typical_low_minor, typical_high_minor, raw_path | **nowa** – kontekst |
| `stats_daily` | watch_id, date, best_payable_minor, median_payable_minor, p10_minor, n_offers, n_eligible, google_level; PK(watch_id, date) | |
| `alerts` | id, watch_id, kind, dedup_key, offer_id, payable_minor, created_at_utc, sent_at_utc, telegram_message_id, payload; UNIQUE(kind, dedup_key) | ponowienia gdy sent_at NULL |
| `purchases` | id, watch_id, itinerary_id, offer_id, paid_pln_minor, purchased_at_utc, notes | po `/kupione` |

## Indeksy
- `offers(itinerary_id, observed_at_utc)`; `offers(observed_at_utc)`
- `queries(provider, created_at_utc)` – liczenie budżetu w miesiącu
- `queries(request_hash, created_at_utc)` – cache 60 min
- `evaluations(config_hash, buy_eligible, payable_pln_minor)` – top N i decyzja
- `itineraries(watch_id, out_date, ret_date)`

## Wielkość
~215 zapytań × ~20 ofert/dzień ≈ 4 300 ofert/dzień ≈ 150 tys. do połowy listopada → kilkadziesiąt MB. Bez partycjonowania i archiwizacji w MVP.

## Migracje
Pliki `NNN_*.sql`, aplikowane w transakcji, tylko w przód. Przed migracją na produkcji: `sqlite3 .backup`.
