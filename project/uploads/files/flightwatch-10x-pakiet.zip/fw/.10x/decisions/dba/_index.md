# DBA – indeks
Zasady: grosze jako INTEGER, UTC jako TEXT ISO, oferty insert-only, wyliczenia wersjonowane `config_hash`, WAL.

| Feature | Plik | Status |
|---|---|---|
| flightwatch-mvp | flightwatch-mvp.md | Projekt (przed implementacją) |
