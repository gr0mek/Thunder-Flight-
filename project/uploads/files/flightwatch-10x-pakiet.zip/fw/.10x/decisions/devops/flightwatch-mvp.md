# DevOps – flightwatch-mvp (plan przed developmentem)

## Infrastruktura
- VPS: Ubuntu 24.04, 2 vCPU / 2–4 GB RAM wystarczy (np. Hetzner CX22). Strefa systemu UTC; strefa aplikacji z configu.
- Użytkownik `flightwatch` bez sudo, katalog `/opt/flightwatch`, dane `/var/lib/flightwatch` (700).
- Python i zależności: `uv` + `uv.lock`.

## CI (GitHub Actions, na push i PR)
`uv sync --frozen` → `ruff check` → `mypy` (silnik) → `pytest --cov` → `pip-audit` → `gitleaks`.

## Jednostki systemd (`deploy/systemd/`)
| Jednostka | Typ | Harmonogram |
|---|---|---|
| `fw-scan-full.timer/.service` | oneshot | 07:30 Europe/Warsaw, `Persistent=true` |
| `fw-scan-confirm.timer/.service` | oneshot | 19:30 |
| `fw-insights.timer/.service` | oneshot | 08:00 |
| `fw-stats.timer/.service` | oneshot | 20:30 |
| `fw-report-weekly.timer/.service` | oneshot | niedz. 18:00 |
| `fw-backup.timer/.service` | oneshot | 03:15 |
| `fw-bot.service` | simple | `Restart=always` |

Timery z `OnCalendar=*-*-* 07:30:00 Europe/Warsaw`. Skany przez `flock -n /run/flightwatch/scan.lock`. `EnvironmentFile=/opt/flightwatch/.env`.

## Wdrożenie (`deploy/deploy.sh`)
`git pull --ff-only` → `uv sync --frozen` → `backup` → `flightwatch migrate` → `systemctl restart fw-bot` → `flightwatch scan --mode confirm --dry-run --limit 1`.

## Wycofanie
`git checkout <poprzedni tag>` + `uv sync` + przywrócenie bazy z kopii sprzed migracji (`/var/lib/flightwatch/backups/pre-migrate-*.db`). Tagi `vYYYY.MM.DD-N` przy każdym wdrożeniu.

## Kopia zapasowa
`sqlite3 flightwatch.db ".backup ..."` → `restic` (szyfrowane) do Backblaze B2; retencja 14 dziennych + 8 tygodniowych. Test odtworzenia raz, w sesji 5.
