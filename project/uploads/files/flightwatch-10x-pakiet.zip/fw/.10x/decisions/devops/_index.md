# DevOps – indeks
Zasady: systemd zamiast Dockera, uv.lock, wdrożenie skryptem z backupem przed migracją, CI blokuje merge przy czerwonych testach.

| Feature | Plik | Status |
|---|---|---|
| flightwatch-mvp | flightwatch-mvp.md | Plan gotowy |
