# Security – flightwatch-mvp (model zagrożeń przed developmentem)

## Zasoby
Klucze API (Ignav, SerpApi), token bota Telegrama, dostęp SSH do VPS, baza z historią i zakupem, kopie zapasowe.

## Zagrożenia i zabezpieczenia
| Zagrożenie | Prawdop. | Skutek | Zabezpieczenie |
|---|---|---|---|
| Klucz SerpApi w logach (parametr URL) | wysokie | zużycie limitu przez kogoś innego | filtr redagujący + test, że log nie zawiera klucza |
| Sekrety w repo | średnie | jw. | `.env` w `.gitignore`, `.env.example` bez wartości, `gitleaks` w CI |
| Obcy czat steruje botem | średnie | fałszywe `/kupione`, wyciek danych | whitelist `TELEGRAM_CHAT_ID`, potwierdzenie przyciskiem |
| Przejęcie VPS | niskie | wszystkie klucze | SSH tylko kluczem, bez roota, `ufw` (tylko 22), `unattended-upgrades`, fail2ban |
| Zbyt szerokie uprawnienia plików | średnie | odczyt `.env` przez innych | użytkownik `flightwatch`, `.env` 600, katalog `data/` 700 |
| Kopia zapasowa poza serwerem | niskie | odczyt historii | szyfrowanie po stronie klienta (restic) |
| Złośliwy link w odpowiedzi dostawcy | niskie | phishing przez alert | akceptowane tylko `https://`, domena pokazana w alercie |
| Zależności z podatnościami | niskie | RCE | `uv lock`, `pip-audit` w CI |
| Naruszenie regulaminu (fast-flights) | średnie | blokada IP | tylko zapas, limit zapytań, nigdy jako główne źródło |

## Dane osobowe
System nie przechowuje danych pasażerów (imion, paszportów). Tylko liczba i wiek dziecka w configu.

## Bramki
- Przed sesją 5: przegląd `.env` na serwerze, test redakcji logów, test whitelisty bota.
