# Security – indeks
Zasady: sekrety tylko w `.env` (600), redakcja w logach, bot tylko dla jednego czatu, brak portów przychodzących poza SSH.

| Feature | Plik | Status |
|---|---|---|
| flightwatch-mvp | flightwatch-mvp.md | Model zagrożeń gotowy |
