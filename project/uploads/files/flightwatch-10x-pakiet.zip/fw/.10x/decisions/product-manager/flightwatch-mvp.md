# Product Manager – flightwatch-mvp

## Użytkownik
Gromek (+ Ola): rodzic planujący wyjazd 2+1, sprawdza Telegram, chce jednej jasnej informacji „kup teraz / jeszcze nie”, a nie tabel.

## Historyjki (MVP)
1. Jako kupujący dostaję **KUP** na Telegramie w ciągu 5 min od pojawienia się oferty ≤ 11 000 zł z bagażem i miejscami, z linkiem i warunkami zmiany powrotu.
2. Jako kupujący dostaję **BLISKO** raz dziennie, gdy najlepsza oferta jest ≤ 7% nad progiem.
3. Jako kupujący dostaję **TERMIN** 8.11 z 3 najlepszymi opcjami, jeśli KUP nie nastąpił.
4. Jako kupujący wpisuję `/top3` i widzę najtańszą, najszybszą i kompromis z kwotą, czasem, przesiadkami i elastycznością.
5. Jako kupujący wpisuję `/status` i widzę: ostatni skan, najlepszą kwotę dziś vs mediana, ocenę Google, budżet API.
6. Jako kupujący wpisuję `/kupione` i system przestaje wysyłać alerty zakupu.
7. Jako właściciel dostaję wiadomość, gdy skan nie działa > 24 h albo kończy się budżet API.

## Kryteria akceptacji (wybrane)
- Każda kwota w alercie jest dla 3 osób, z dopiskiem ceny za dorosłego.
- Oferta z nieznanym kosztem bagażu lub ceną szacowaną nigdy nie daje KUP.
- Alert KUP dla tej samej oferty nie powtarza się, dopóki kwota nie spadnie o kolejne ≥ 3%.
- Godziny w alertach w czasie lokalnym lotniska, z nazwą miasta.

## Zakres
W MVP: patrz spec §2. Poza MVP (sesja 6): huby, dolot tanią linią, WMI/VIE/PRG/BUD, warianty elastyczności, open-jaw, monitor po zakupie, Streamlit.

## Miary sukcesu
- Dane zbierane od 11.10 bez przerwy > 24 h.
- Decyzja zakupowa podjęta do 15.11 na podstawie ≥ 3 tygodni danych.
- Zakup ≤ 11 000 zł albo świadoma decyzja powyżej progu z TERMIN.

## Pytania otwarte
1. Akceptacja zawężenia MVP (spec §9.1).
2. Nocleg w hubie a kwota do zapłaty (sesja 6).
