# Product Manager – indeks
Zasady: jedna decyzja zakupowa na obserwację, komunikaty po polsku, mniej alertów > więcej alertów.

| Feature | Plik | Status |
|---|---|---|
| flightwatch-mvp | flightwatch-mvp.md | Proponowany |
