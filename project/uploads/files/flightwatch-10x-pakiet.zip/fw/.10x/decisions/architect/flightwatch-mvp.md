# Architect – flightwatch-mvp

ADR: 001, 002, 003, 004, 005. Spec: `specs/2026-10-03-flightwatch-mvp-design.md`.

## Struktura repo
```
flightwatch/
  __init__.py
  cli.py                 # Typer: migrate, scan, insights, stats, report, bot, budget
  config.py              # pydantic: AppConfig, Watch, Filters, EffectiveCost, ...
  models.py              # Offer, Itinerary, Segment, FareConditions, SearchQuery, Evaluation
  clock.py               # Clock (wstrzykiwany, w testach zamrożony)
  logging.py             # konfiguracja + filtr redagujący sekrety
  fx.py                  # NBP → fx_rates
  db/
    connection.py        # WAL, busy_timeout, foreign_keys
    migrations/001_init.sql
    migrate.py
    repo.py              # zapisy/odczyty; jedyne miejsce z SQL
  providers/
    base.py              # Provider, ProviderCapabilities, wyjątki
    chain.py             # ProviderChain (fallback + retry)
    ignav.py  serpapi.py  fast_flights.py
  planner/
    grid.py              # siatka zapytań full/confirm
    budget.py            # BudgetLedger
    cache.py             # same_query_ttl
  engine/
    normalize.py         # surowe → Offer (PLN, UTC, strefy)
    filters.py           # filtry twarde per typ trasy i kierunek
    pricing.py           # kwota do zapłaty
    cost.py              # koszt K + kary
    ranking.py           # najtańsza / najszybsza / kompromis
    decision.py          # KUP / BLISKO / TERMIN / MISTAKE_FARE / OBSERWUJ
    stats.py             # dzienne statystyki, mediana, p10
  alerts/
    format.py            # teksty PL
    dispatcher.py        # deduplikacja + wysyłka + ponowienia
    telegram.py          # klient Bot API
    bot.py               # komendy
data/
  airports.yaml          # IATA → nazwa, miasto, strefa IANA
  fare_rules.yaml        # ręczne reguły taryf
tests/
  fixtures/{ignav,serpapi,fast_flights}/
  unit/  integration/
deploy/
  systemd/*.service *.timer
  backup.sh  deploy.sh
```

## Kontrakty (zamrożone po sesji 1)
- `SearchQuery`: watch_id, origin(s), destination, out_date, ret_date | None, adults, child_ages, infants, cabin, currency, mode (`full|confirm|recheck`).
- `Offer`: provider, observed_at (UTC), itinerary (segmenty tam/z powrotem), total_amount_minor + currency, total_pln_minor, per_adult_pln_minor, price_basis (`group_quoted|estimated`), fare_brand per kierunek, fare_conditions (`FareConditions | None`), booking_url, raw_ref.
- `FareConditions`: change_allowed, change_fee_minor, fare_difference_applies, refund_allowed, refund_fee_minor, source (`provider|fare_rules|unknown`).
- `Evaluation`: offer_id, config_hash, passes, reasons[], payable_pln_minor, ancillaries_known, effective_cost_pln_minor, components{tickets, bags, seats, transfer, time, penalties}, buy_eligible.
- `itinerary_key` = sha1(posortowane: carrier+flight_no+dep_utc każdego segmentu | fare_brand tam | fare_brand powrót).

## Granice i zasady zależności
`engine/` nie importuje `db/`, `providers/` ani `alerts/` (czyste funkcje). `providers/` nie zna bazy. SQL tylko w `db/repo.py`. Konfiguracja przekazywana jawnie, bez zmiennych globalnych.

## Tryby awarii
| Awaria | Skutek | Ograniczenie |
|---|---|---|
| dostawca zmienia format | brak ofert | surowa odpowiedź zapisana, alert > 20% błędów, test kontraktu na fixture |
| koniec budżetu w połowie miesiąca | brak danych live | rezerwa 15%, alert 80%, fast-flights jako zapas (bez KUP, jeśli bez cen grupy) |
| serwer padł | dziura w danych | `Persistent=true` w timerach, heartbeat 24 h |
| zła strefa czasowa | złe filtry | strefy z `airports.yaml`, testy DST |
| zdublowany KUP | spam | unikalny `dedup_key` w `alerts` |
