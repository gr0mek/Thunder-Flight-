# Architect – indeks
Zasady: czysty silnik bez I/O, jedno miejsce z SQL, konfiguracja jako jedyne źródło wartości, UTC w środku i strefa lokalna tylko na brzegach.

| Feature | Plik | ADR | Status |
|---|---|---|---|
| flightwatch-mvp | flightwatch-mvp.md | 001–005 | Proponowany |
