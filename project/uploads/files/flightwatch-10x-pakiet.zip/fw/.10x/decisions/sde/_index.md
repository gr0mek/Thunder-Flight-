# SDE – indeks
Nic jeszcze nie zbudowano. Pierwszy wpis po sesji 1: co powstało, odstępstwa od planu, dług techniczny.

| Feature | Plik | Status |
|---|---|---|
| flightwatch-mvp | flightwatch-mvp.md | Nie rozpoczęto |
