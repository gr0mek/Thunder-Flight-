# SDE – flightwatch-mvp

**Stan:** nie rozpoczęto (czeka na akceptację specu i wynik sesji 0).

## Zbudowane
_(uzupełnia SDE po każdej sesji)_

## Odstępstwa od planu
_(brak)_

## Dług techniczny
_(brak)_
