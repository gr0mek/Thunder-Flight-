# Staff Engineer – indeks
Standardy przekrojowe: grosze jako int, UTC + zoneinfo, wstrzykiwany zegar, redakcja sekretów w logach, ruff + mypy dla silnika.

| Feature | Plik | Status |
|---|---|---|
| flightwatch-mvp | flightwatch-mvp.md | Proponowany |
