# Staff Engineer – flightwatch-mvp

## Standardy kodu
- Python 3.12, `ruff` (lint + format), typy wszędzie, `mypy --strict` dla `engine/` i `models.py`.
- Pieniądze: `int` w groszach (`*_minor`); kurs i przeliczenia przez `Decimal` z zaokrągleniem `ROUND_HALF_UP`. Nigdy `float` dla kwot.
- Czas: wszystko w UTC (`datetime` z tzinfo); strefa lokalna przez `zoneinfo` i `airports.yaml` tylko przy filtrach i wyświetlaniu. Naiwne `datetime` = błąd (walidator pydantic).
- `Clock` wstrzykiwany do planera, decyzji i alertów → testy z zamrożonym czasem.
- Nazwy i kod po angielsku, komunikaty dla użytkownika i komentarze po polsku.

## Sprawy przekrojowe
- **Logowanie:** `logging` stdlib, format klucz=wartość, `run_id` w każdej linii. Filtr redagujący: wartości z `.env` oraz parametry `api_key`, `token`, `key` w URL-ach zamieniane na `***`.
- **Błędy:** hierarchia `FlightWatchError` → `ConfigError`, `ProviderError` (`Transient`, `Permanent`), `BudgetExceeded`, `ParseError`. Bez gołego `except:`.
- **HTTP:** jeden `httpx.Client` na proces, timeout 30 s, nagłówek User-Agent, ponowienia tylko dla błędów przejściowych.
- **Konfiguracja:** `config_hash` (sha256 znormalizowanego YAML) zapisywany w `runs` i `evaluations`.
- **Surowe odpowiedzi:** `data/raw/YYYY-MM-DD/<query_id>.json.gz`, retencja 30 dni; najlepsze kandydaty na fixtures.

## Wzorce
- Repozytorium (`db/repo.py`) zamiast ORM.
- Funkcje czyste w silniku: wejście = dane + config, wyjście = wynik; bez efektów ubocznych.
- Rejestr dostawców po nazwie z configu.

## Czego nie robimy
Async (niepotrzebny przy ~200 zapytaniach), ORM, kolejki zadań, Docker (systemd wystarczy), Alembic.
