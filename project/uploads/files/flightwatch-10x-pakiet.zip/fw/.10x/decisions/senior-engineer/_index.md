# Senior Engineer – indeks
Zasady: determinizm (sortowanie z kluczem rozstrzygającym), powody odrzucenia zawsze zapisywane, brak cichych wartości domyślnych dla stref i kursów.

| Feature | Plik | Status |
|---|---|---|
| flightwatch-mvp | flightwatch-mvp.md | Podejście gotowe |
