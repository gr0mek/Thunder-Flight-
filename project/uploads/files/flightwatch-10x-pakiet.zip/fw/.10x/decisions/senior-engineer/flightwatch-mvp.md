# Senior Engineer – flightwatch-mvp (podejście do implementacji)

## Trudne miejsca i jak je robić
1. **Cena dla grupy (T2.1).** Wysyłaj `adults=2`, `children` z wiekiem. Jeśli API zwraca ceny per typ pasażera, sumuj pozycje z odpowiedzi; nigdy nie mnóż ceny dorosłego. Gdy brak ceny dziecka → `price_basis="estimated"`.
2. **Klucz itinerarium (T1.4).** Ten sam lot u różnych dostawców musi dać ten sam klucz: normalizuj numer lotu (`LH 1234` → `LH1234`), czas odlotu do UTC z dokładnością do minuty.
3. **Filtry kierunkowe (T3.1).** Filtry liczone osobno dla `out` i `ret`; wynik = lista powodów odrzucenia (np. `ret_arrival_night`, `out_too_long`), zapisywana w `evaluations.reasons_json` – przyda się w `/top3` do wyjaśnień.
4. **Okno przylotu.** Porównuj `arr_local.time()` w strefie lotniska przylotu; okno włącznie z oboma końcami; `forbidden_arrival_local` dla powrotu w strefie WAW/KRK/GDN/BER.
5. **Kara za godziny (T3.3).** Godziny = od odlotu z pierwszego lotniska do przylotu na ostatnie (UTC), osobno tam i z powrotem; `soft_max` stosowany per kierunek.
6. **Top 20 w trybie confirm (T2.4).** Sortuj po `(payable, K, itinerary_key)` – trzeci klucz daje determinizm.
7. **Bramka budżetu.** `reserve()` w transakcji `BEGIN IMMEDIATE`; wpis w `queries` ze statusem `reserved`, potem `ok/error`. Błędy też kosztują – liczą się.
8. **Deduplikacja alertów (T4.2).** `dedup_key` dla KUP = `itinerary_key`; nowy KUP tylko gdy kwota spadła o ≥ 3% od ostatniego wysłanego. BLISKO: `date`. TERMIN: `watch_id`.
9. **Potwierdzenie spadku.** Po skanie: jeśli `best_payable_today < best_payable_prev * 0.95` → `recheck` tej oferty z pominięciem cache; KUP dopiero na wyniku rechecku.
10. **Strefy hubów.** `airports.yaml` musi zawierać wszystkie lotniska przesiadkowe z odpowiedzi; brak strefy = `ConfigError` z kodem IATA (żeby dopisać), nie cichy UTC.

## Kolejność plików w S1
`config.py` → `models.py` → `db/migrations/001_init.sql` → `db/repo.py` → `providers/base.py` → `logging.py` → testy.

## Prompt dla Claude Code (sesja 1)
> Przeczytaj `CLAUDE.md`, `config.yaml` i `.10x/` (spec, ADR 001–005, decisions/architect, staff-engineer, dba, qa). Zrealizuj zadania T1.1–T1.4 z `.10x/decisions/engineering-manager/flightwatch-mvp.md` zgodnie z kontraktami z `decisions/architect/flightwatch-mvp.md`. Bez prawdziwych wywołań API. Na koniec: `pytest`, `ruff check`, `mypy` dla `models.py`, aktualizacja `.10x/decisions/sde/flightwatch-mvp.md`, `.10x/status.md` i `.10x/handoff.md`.
