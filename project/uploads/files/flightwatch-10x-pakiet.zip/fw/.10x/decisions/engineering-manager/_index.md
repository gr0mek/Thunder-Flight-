# Engineering Manager – indeks
Zasady: zadania ≤ pół dnia, każda sesja kończy się zielonymi testami, spike przed kodem zależnym od zewnętrznego API.

| Feature | Plik | Status |
|---|---|---|
| flightwatch-mvp | flightwatch-mvp.md | Plan gotowy |
