# Engineering Manager – flightwatch-mvp (plan dostarczenia)

Termin: zbieranie danych od **11.10.2026**. Bufor: 0,5 dnia. Ścieżka krytyczna: S0 → S2 → S3 → S4 → S5.

| Sesja | Dzień | Zadania (≤ pół dnia każde) | Bramka wyjścia |
|---|---|---|---|
| **S0 Spike** | nd 4.10 | T0.1 prawdziwe zapytanie Ignav WAW→DPS 2+1 (RT, OW, multi-origin); T0.2 to samo SerpApi (Google Flights + price insights); T0.3 zapis odpowiedzi jako fixtures + tabela możliwości | tabela „jest / nie ma” dla: ceny grupy z dzieckiem, warunki taryfy, multi-origin, link, waluta. Decyzja: Ignav zostaje głównym? |
| **S1 Szkielet** | pn 5.10 | T1.1 repo, uv, ruff, CI; T1.2 `config.py` + testy walidacji; T1.3 `001_init.sql` + migrate + repo; T1.4 `models.py`, `Provider` ABC, `airports.yaml`, logging z redakcją | pytest zielony, CI zielony, kontrakty zamrożone |
| **S2 Dostawcy** | wt–śr 6–7.10 | T2.1 Ignav + testy na fixtures; T2.2 SerpApi (insights); T2.3 fast-flights (zapas); T2.4 ProviderChain + BudgetLedger + cache; T2.5 `fx.py` (NBP) | `flightwatch scan --mode full --dry-run` na fixtures zapisuje oferty |
| **S3 Silnik** | czw 8.10 | T3.1 normalize + filtry (strefy, DST); T3.2 pricing + `fare_rules.yaml` (pierwsze linie z S0); T3.3 cost K + ranking | testy brzegowe z `qa/` zielone, pokrycie silnika ≥ 90% |
| **S4 Decyzje i alerty** | pt 9.10 | T4.1 decision + stats; T4.2 dispatcher z deduplikacją + format PL; T4.3 bot (`/status`, `/top3`, `/kupione`, `/budzet`) z whitelistą | test integracyjny pełnego skanu zielony, wiadomość testowa na Telegramie |
| **S5 Serwer** | sob 10.10 | T5.1 VPS hardening + użytkownik + `.env`; T5.2 systemd + deploy.sh + healthchecks; T5.3 backup restic + test odtworzenia; T5.4 pierwszy prawdziwy skan | pełny skan na produkcji, heartbeat działa, budżet zgodny z ADR-004 |
| **Start** | nd 11.10 | obserwacja pierwszej doby, uzupełnienie `fare_rules.yaml` dla linii z danych | 2 skany bez interwencji |
| S6 | od 12.10 | huby, dolot tanią linią, warianty elastyczności, monitor po zakupie, Streamlit | osobny brainstorming i ADR |

## Ryzyka harmonogramu
| Ryzyko | Plan B |
|---|---|
| Ignav bez cen dziecka / warunków | SerpApi głównym źródłem dla potwierdzeń KUP (do 250/mies. wystarczy na confirm top 5), Ignav jako radar |
| S2 się przeciąga (format odpowiedzi) | fast-flights przesunięty do S6 |
| Brak czasu na S5 w sobotę | start 11.10 z serwera w trybie ręcznym `scan` (cron), systemd w S6 |

## Twoje zadania przed S0 (ok. 45 min)
VPS, klucze Ignav i SerpApi, bot Telegrama (token + chat_id), konto healthchecks.io, Backblaze B2 (opcjonalnie), prywatne repo z `CLAUDE.md`, `config.yaml` i katalogiem `.10x/`.
