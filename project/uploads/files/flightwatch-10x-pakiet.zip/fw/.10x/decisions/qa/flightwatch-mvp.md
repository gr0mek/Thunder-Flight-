# QA – flightwatch-mvp (strategia testów przed developmentem)

## Piramida
- **Jednostkowe (większość):** `engine/*`, `config.py`, `planner/*`, `alerts/format.py`. Czyste funkcje, bez sieci i dysku.
- **Kontraktowe dostawców:** parsowanie zapisanych odpowiedzi z `tests/fixtures/` (z sesji 0 i pierwszych skanów). Zero prawdziwych wywołań w CI.
- **Integracyjny:** pełny `scan` na SQLite w pamięci, fałszywy dostawca, zamrożony zegar, fałszywy Telegram → sprawdza zapis, decyzję i deduplikację.
- **Dymny na produkcji (sesja 5):** `flightwatch scan --mode confirm --dry-run --limit 3` z prawdziwym API.

## Przypadki brzegowe (obowiązkowe testy)
| Obszar | Przypadek |
|---|---|
| Strefy czasowe | powrót 28.03.2027 (zmiana czasu w Europie): przylot 05:30 i 06:30 czasu lokalnego |
| Strefy czasowe | wylot 31.12, przylot 1.01 05:00 WITA → mieści się w oknie |
| Okna przylotu | granice 05:00 i 12:59 włącznie, 13:00 odrzucone |
| Nocna przesiadka | przesiadka 00:59–05:01 vs okno 01:00–05:00 w strefie huba |
| Ceny | oferta `estimated` ≤ progu → brak KUP |
| Ceny | brak reguły bagażu → brak KUP, jest w rankingu |
| Ceny | kwota dokładnie 11 000,00 zł → KUP; 11 000,01 → BLISKO |
| Waluty | USD z kursem z dnia; brak kursu > 3 dni → brak KUP |
| Świeżość | cena sprzed 61 min → brak KUP |
| Deduplikacja | ta sama oferta dwa razy → jeden KUP; spadek o ≥ 3% → kolejny |
| Mistake fare | < 7 dni danych → brak alertu |
| Budżet | 100% zużycia → dostawca pominięty, następny w kolejce |
| Konfiguracja | `date_from > date_to`, próg ≤ 0, nieznany IATA → czytelny błąd po polsku |
| Planer | tryb confirm wybiera deterministycznie top 20 przy remisach |
| Bot | komenda z obcego chat_id → ignorowana |
| Logi | klucz API nie występuje w żadnej linii logu |

## Bramki jakości (każda sesja)
- `pytest` zielony, `ruff check` czysty, `mypy --strict flightwatch/engine flightwatch/models.py` czysty.
- Pokrycie `engine/` ≥ 90%, całość ≥ 75% (`pytest-cov`).
- Każdy błąd znaleziony w produkcji → najpierw test, potem poprawka.

## Narzędzia
pytest, pytest-cov, time-machine (zamrażanie czasu), respx (mock httpx), hypothesis (właściwości kwot: suma składników = kwota).
