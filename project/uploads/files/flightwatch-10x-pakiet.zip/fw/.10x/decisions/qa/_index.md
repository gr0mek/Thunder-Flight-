# QA – indeks
Zasady: fixtures zamiast prawdziwych API, zamrożony zegar, testy DST i granic progów obowiązkowe.

| Feature | Plik | Status |
|---|---|---|
| flightwatch-mvp | flightwatch-mvp.md | Strategia gotowa |
