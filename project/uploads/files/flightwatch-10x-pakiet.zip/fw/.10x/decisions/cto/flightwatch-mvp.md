# CTO – flightwatch-mvp

## Problem
Kupić bilety WAW→DPS dla 2+1 na zimę 2026/27 w cenie ≤ 11 000 zł z bagażem i miejscami razem, z przylotem rano i możliwie elastycznym powrotem. Decyzja do 15.11.2026.

## Build vs buy
| Opcja | Werdykt | Powód |
|---|---|---|
| Alerty Google Flights / Skyscanner | uzupełnienie, nie zamiennik | cena za 1 osobę lub bez bagażu, brak okien przylotu, brak kosztu dojazdu i elastyczności, jedna trasa na alert |
| Hopper / aplikacje predykcyjne | nie | zamknięty model, brak tras alternatywnych i rodziny 2+1 |
| **Własny FlightWatch** | **budujemy** | pełna kwota dla grupy, filtry kierunkowe, K, warunki zmiany, kilka lotnisk, budżet pod kontrolą |

Rekomendacja równoległa: ustaw ręcznie 1–2 darmowe alerty w Google Flights (WAW→DPS) jako sieć bezpieczeństwa w pierwszym tygodniu.

## Kierunek technologiczny
Python 3.12, SQLite (WAL), httpx, pydantic v2, Typer, python-telegram-bot, pytest, uv, systemd. Uzasadnienie: ADR-001.

## Koszty miesięczne (szacunek)
VPS ok. 20–25 zł, Ignav ok. 13–15 USD przy ~6 400–7 600 zapytaniach, SerpApi 0 zł, Telegram 0 zł, kopia zapasowa ~0 zł (Backblaze B2 w darmowym limicie).

## Kryteria zakończenia (kill / pivot)
- Sesja 0 pokazuje, że Ignav nie daje cen dla grupy z dzieckiem → głównym źródłem zostaje SerpApi w planie płatnym (75 USD/mies.) albo fast-flights z domowego komputera. Decyzja w dniu spike'a.
- Do 8.11 brak ceny ≤ 11 770 zł → raport TERMIN z najlepszą opcją i decyzja ręczna; system nie podnosi progu sam.
