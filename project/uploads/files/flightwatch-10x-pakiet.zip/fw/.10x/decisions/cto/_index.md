# CTO – indeks
Zasady przekrojowe: osobiste narzędzie, minimum infrastruktury, koszt < 100 zł/mies., żadnych funkcji poza decyzją zakupową.

| Feature | Plik | Status |
|---|---|---|
| flightwatch-mvp | flightwatch-mvp.md | Proponowany |
