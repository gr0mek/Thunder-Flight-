# SRE – flightwatch-mvp (plan przed developmentem)

## SLO (do 15.11.2026)
| SLO | Cel |
|---|---|
| Skuteczność zaplanowanych skanów | ≥ 95% tygodniowo |
| Maks. przerwa w danych live | ≤ 24 h |
| Opóźnienie KUP (obserwacja → Telegram) | ≤ 5 min |
| Zużycie budżetu Ignav | ≤ 95% miesięcznie (stałe ≈ 80%) |

## Monitorowanie
- **Heartbeat:** healthchecks.io (darmowy), osobny check dla `scan-full`, `scan-confirm`, `bot`. Ping na start i sukces; brak pingu → e-mail/Telegram z healthchecks.
- **Alerty administracyjne** (Telegram, prefiks 🛠): skan zakończony błędem, > 20% błędów parsowania, budżet 80% i 100%, 401/403 dostawcy, kurs NBP starszy niż 3 dni, dysk > 80%.
- **Raport dzienny 20:30:** liczba zapytań, ofert, błędów, najlepsza kwota, budżet.
- Logi w journald (`journalctl -u fw-*`), retencja 30 dni.

## Runbook
| Objaw | Diagnoza | Działanie |
|---|---|---|
| brak heartbeatu | `systemctl list-timers fw-*`, `journalctl -u fw-scan-full -n 100` | naprawa, `systemctl start fw-scan-full.service` ręcznie |
| 401/403 Ignav | klucz wygasł lub zablokowany | nowy klucz w `.env`, `systemctl restart fw-bot`, ręczny skan |
| budżet 100% | `flightwatch budget` | zostaje fast-flights (bez KUP) i SerpApi; rozważ dokupienie lub tylko tryb confirm |
| `database is locked` | `fuser data/flightwatch.db` | sprawdź zawieszony proces, `flock` zwolni się po zabiciu |
| zero ofert, brak błędów | dostawca zmienił format | porównaj surową odpowiedź z fixture, popraw parser + test |
| bot milczy | `systemctl status fw-bot` | restart; alerty niewysłane wyjdą przy następnym przebiegu |
| pełny dysk | `du -sh /var/lib/flightwatch/*` | skróć retencję `data/raw` |

## Gotowość operacyjna (bramka sesji 5)
Pełny dzień pracy na produkcji bez ręcznej interwencji, test alarmu heartbeat (zatrzymany timer), test odtworzenia kopii.
