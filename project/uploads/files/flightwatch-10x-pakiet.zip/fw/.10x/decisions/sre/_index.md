# SRE – indeks
Zasady: każdy timer ma heartbeat, każda klasa błędu ma wpis w runbooku, alerty administracyjne oddzielone prefiksem od zakupowych.

| Feature | Plik | Status |
|---|---|---|
| flightwatch-mvp | flightwatch-mvp.md | Plan gotowy |
